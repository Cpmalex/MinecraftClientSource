package dev.sixseven.license;

import org.slf4j.Logger;

public final class LicenseGuard {
   private LicenseGuard() {
   }

   public static byte[] enforce(Logger var0) {
      return null;
   }
}
